<?php
header('Content-Type: application/json; charset=utf-8');

/**
 * Endpoint para eliminar un producto y sus entradas de almacén asociadas.
 * - Valida que el ID recibido sea válido.
 * - Usa transacción para garantizar que ambas tablas queden consistentes.
 */

// 1) Leer y validar ID
$id = intval($_POST['id'] ?? 0);
if ($id <= 0) {
    // ID no válido → responder con 400 Bad Request
    http_response_code(400);
    echo json_encode([
        'status'  => 'error',
        'message' => 'ID inválido',
        'newId'   => null
    ]);
    exit;
}

// 2) Conexión a la base de datos
$mysqli = new mysqli('localhost','root','','tienda');
if ($mysqli->connect_error) {
    // Error de conexión → responder con 500 Internal Server Error
    http_response_code(500);
    echo json_encode([
        'status'  => 'error',
        'message' => 'Error de conexión: '.$mysqli->connect_error,
        'newId'   => null
    ]);
    exit;
}
$mysqli->begin_transaction();  // Iniciar transacción

try {
    // 3a) Eliminar todas las filas de 'almacen' vinculadas a este producto
    //     Usamos producto_id (no la columna ID de almacen)
    $delAlm = $mysqli->prepare("DELETE FROM almacen WHERE producto_id = ?");
    $delAlm->bind_param('i', $id);
    if (!$delAlm->execute()) {
        throw new Exception('Error borrando almacen: '.$delAlm->error);
    }
    $delAlm->close();

    // 3b) Eliminar el registro de la tabla 'productos'
    $delProd = $mysqli->prepare("DELETE FROM productos WHERE ID = ?");
    $delProd->bind_param('i', $id);
    if (!$delProd->execute()) {
        throw new Exception('Error borrando producto: '.$delProd->error);
    }
    $delProd->close();

    // 4) Confirmar cambios si ambas eliminaciones tuvieron éxito
    $mysqli->commit();
    echo json_encode([
        'status'  => 'ok',
        'message' => null,
        'newId'   => null
    ]);

} catch (Exception $e) {
    // En caso de error, deshacer todas las operaciones previas
    $mysqli->rollback();
    http_response_code(500);
    echo json_encode([
        'status'  => 'error',
        'message' => $e->getMessage(),
        'newId'   => null
    ]);
}

$mysqli->close();