<?php
// addAlmacen.php

/**
 * Recibe un JSON con:
 *  - producto_id: ID del producto existente
 *  - cantidad:   número de fechas esperadas
 *  - fechaCaducidad: lista CSV de fechas (formato dd/mm/YYYY)
 * Inserta una fila en `almacen` por cada fecha indicada.
 */

error_reporting(E_ALL & ~E_NOTICE & ~E_WARNING);
ini_set('display_errors', '0');

header('Content-Type: application/json');
header("Access-Control-Allow-Origin: *");             // Permitir llamadas desde cualquier origen
header("Access-Control-Allow-Methods: POST");         // Solo POST
header("Access-Control-Allow-Headers: Content-Type"); // Cabeceras permitidas

// 1) Leer y decodificar el JSON de entrada
$raw  = file_get_contents('php://input');
$body = json_decode($raw, true);
if (json_last_error() !== JSON_ERROR_NONE) {
    // JSON mal formado → 400 Bad Request
    http_response_code(400);
    echo json_encode([
        "status"  => "error",
        "message" => "JSON inválido: " . json_last_error_msg()
    ]);
    exit;
}

// Función auxiliar para obtener campos indiferente a mayúsculas/minúsculas
function getField(array $body, string $name) {
    if (isset($body[$name])) return $body[$name];
    $uc = ucfirst($name);
    if (isset($body[$uc])) return $body[$uc];
    return null;
}

// 2) Validar campos obligatorios: producto_id, cantidad y fechaCaducidad
$required = ['producto_id', 'cantidad', 'fechaCaducidad'];
$vals     = [];
foreach ($required as $f) {
    $v = getField($body, $f);
    if ($v === null) {
        // Falta un campo → 400 Bad Request
        http_response_code(400);
        echo json_encode([
            "status"  => "error",
            "message" => "Falta el campo \"$f\""
        ]);
        exit;
    }
    $vals[$f] = $v;
}

$producto_id    = intval($vals['producto_id']);
$cantidad       = intval($vals['cantidad']);
// Separar CSV de fechas y limpiar espacios
$fechas = array_filter(array_map('trim', explode(',', $vals['fechaCaducidad'])));

// Verificar que el número de fechas coincide con la cantidad
if (count($fechas) !== $cantidad) {
    http_response_code(400);
    echo json_encode([
        "status"  => "error",
        "message" => "El número de fechas no coincide con la cantidad"
    ]);
    exit;
}

// 3) Conectar a la base de datos
$mysqli = new mysqli("localhost", "root", "", "tienda");
if ($mysqli->connect_error) {
    // Error de conexión → 500 Internal Server Error
    http_response_code(500);
    echo json_encode([
        "status"  => "error",
        "message" => "Error de conexión: " . $mysqli->connect_error
    ]);
    exit;
}

// 4) Preparar la inserción en `almacen`
//    STR_TO_DATE convierte la cadena a formato DATE de MySQL
$stmt = $mysqli->prepare("
    INSERT INTO almacen
      (producto_id, Cantidad, FechaCaducidad)
    VALUES (?, ?, STR_TO_DATE(?, '%d/%m/%Y'))
");

foreach ($fechas as $f) {
    $cantidadPorFecha = 1;  // Insertar una unidad por fecha
    $stmt->bind_param("iis", $producto_id, $cantidadPorFecha, $f);
    if (!$stmt->execute()) {
        // Fallo al insertar una fila → 500 y mensaje
        http_response_code(500);
        echo json_encode([
            "status"  => "error",
            "message" => "Error en INSERT almacen: " . $stmt->error
        ]);
        exit;
    }
}
$stmt->close();
$mysqli->close();

// 5) Respuesta de éxito
echo json_encode([
    "status"  => "ok",
    "message" => "Almacén actualizado para producto_id=$producto_id"
]);