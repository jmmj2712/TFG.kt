<?php 
// getProductos.php

/**
 * Este endpoint devuelve un listado JSON de productos disponibles,
 * opcionalmente filtrados por marca.
 */

// --- Datos de conexión a la base de datos ---
$host = "localhost";
$usuario = "root";
$contrasena = "";
$base_datos = "tienda";

// Crear la conexión y verificar errores
$conexion = new mysqli($host, $usuario, $contrasena, $base_datos);
if ($conexion->connect_error) {
    // Si falla la conexión, terminar la ejecución mostrando el error
    die("Conexión fallida: " . $conexion->connect_error);
}

// Obtener el parámetro 'marca' de la URL y escapar caracteres especiales
$marca = isset($_GET['marca'])
    ? $conexion->real_escape_string($_GET['marca'])
    : "";  // Si no se suministra, usar cadena vacía

// Construir la consulta SQL según si hay filtro de marca
if (!empty($marca)) {
    // Filtrar por la marca indicada y solo productos con Disponibles = 1
    $query = "
        SELECT ID, Producto, Tamano, Precio, Marca, Disponibles, Almacen
        FROM productos
        WHERE Marca = '$marca'
          AND Disponibles = 1
    ";
} else {
    // Sin filtro de marca, devolver todos los disponibles
    $query = "
        SELECT ID, Producto, Tamano, Precio, Marca, Disponibles, Almacen
        FROM productos
        WHERE Disponibles = 1
    ";
}

// Ejecutar la consulta
$resultado = $conexion->query($query);

$productos = array();
if ($resultado && $resultado->num_rows > 0) {
    // Recorrer cada fila y añadir al array de salida
    while ($row = $resultado->fetch_assoc()) {
        $productos[] = $row;
    }
}

// Enviar cabecera HTTP indicando JSON y volcar la respuesta
header('Content-Type: application/json');
echo json_encode($productos);

// Cerrar la conexión al terminar
$conexion->close();
?>