<?php
// getAlmacen.php

/**
 * Endpoint que devuelve en JSON el stock agrupado de productos en almacén,
 * incluyendo cantidad y fecha de caducidad formateada.
 */

// Parámetros de conexión a la base de datos
$host       = "localhost";
$usuario    = "root";
$contrasena = "";
$base_datos = "tienda";

// 1) Conexión a MySQL con manejo de error
$conexion = new mysqli($host, $usuario, $contrasena, $base_datos);
if ($conexion->connect_error) {
    // Responder HTTP 500 y JSON con estado de error si falla la conexión
    http_response_code(500);
    die(json_encode([
        "status"  => "error",
        "message" => "Conexión fallida: " . $conexion->connect_error
    ]));
}

// 2) Consulta con LEFT JOIN para unir productos y sus entradas en 'almacen'
//    - DATE_FORMAT convierte FechaCaducidad a "dd/mm/YYYY"
//    - Sólo incluimos productos con p.Almacen = 1 (tienen stock en almacén)
$query = "
    SELECT 
      p.ID,
      p.Producto,
      p.Tamano,
      p.Precio,
      p.Marca,
      p.Disponibles,
      p.Almacen,
      a.Cantidad,
      DATE_FORMAT(a.FechaCaducidad, '%d/%m/%Y') AS FechaCaducidad
    FROM productos p
    LEFT JOIN almacen a 
      ON p.ID = a.producto_id
    WHERE p.Almacen = 1
    ORDER BY p.Producto
";

$resultado = $conexion->query($query);
if ($resultado === false) {
    // Si la consulta falla, respondemos con HTTP 500 y mensaje de error
    http_response_code(500);
    die(json_encode([
        "status"  => "error",
        "message" => "Error en la consulta: " . $conexion->error
    ]));
}

// 3) Construcción del array de salida
$almacen = [];
while ($row = $resultado->fetch_assoc()) {
    $almacen[] = [
        "ID"             => (int)$row["ID"],
        "Producto"       => $row["Producto"],
        "Tamano"         => $row["Tamano"],
        "Precio"         => (float)$row["Precio"],
        "Marca"          => $row["Marca"],
        "Disponibles"    => (int)$row["Disponibles"],
        "Almacen"        => (int)$row["Almacen"],
        // 'Cantidad' puede ser NULL si no hay registro en 'almacen'
        "Cantidad"       => isset($row["Cantidad"]) && $row["Cantidad"] !== null
                                ? (int)$row["Cantidad"]
                                : null,
        // 'FechaCaducidad' ya viene formateada o NULL
        "FechaCaducidad" => $row["FechaCaducidad"] !== null
                                ? $row["FechaCaducidad"]
                                : null,
    ];
}

// 4) Envío de la respuesta JSON sin escapar UTF-8
header('Content-Type: application/json; charset=utf-8');
echo json_encode($almacen, JSON_UNESCAPED_UNICODE);

// Cierre de la conexión
$conexion->close();