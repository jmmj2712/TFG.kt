<?php
// consumeProduct.php

/**
 * Consume una unidad de un producto en almacén eliminando
 * la entrada con la fecha de caducidad más próxima.
 * Devuelve el nuevo conteo de unidades y la siguiente fecha.
 */

error_reporting(E_ALL & ~E_NOTICE & ~E_WARNING);
ini_set('display_errors', '0');

header('Content-Type: application/json');
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: POST");
header("Access-Control-Allow-Headers: Content-Type");

// 1) Obtener y validar ID de producto
$id = intval($_POST['id'] ?? 0);
if ($id <= 0) {
    http_response_code(400);
    echo json_encode([
        'status'  => 'error',
        'message' => 'ID inválido'
    ]);
    exit;
}

// 2) Conexión a la base de datos
$mysqli = new mysqli('localhost','root','','tienda');
if ($mysqli->connect_error) {
    http_response_code(500);
    echo json_encode([
        'status'  => 'error',
        'message' => 'Error de conexión'
    ]);
    exit;
}

// Iniciar transacción para mantener consistencia
$mysqli->begin_transaction();

try {
    // 3) Seleccionar la fila con la fecha de caducidad más antigua
    $res = $mysqli->query("
        SELECT ID_almacen, FechaCaducidad
        FROM almacen
        WHERE producto_id = $id
        ORDER BY FechaCaducidad ASC
        LIMIT 1
    ");
    if ($res->num_rows === 0) {
        // No hay unidades para consumir
        $mysqli->commit();
        echo json_encode([
            'status'   => 'ok',
            'newCount' => 0,
            'nextDate' => null
        ]);
        exit;
    }
    $row   = $res->fetch_assoc();
    $almId = intval($row['ID_almacen']);  // ID de la fila a eliminar

    // 4) Eliminar esa unidad de almacén
    $del = $mysqli->prepare("
        DELETE FROM almacen
        WHERE ID_almacen = ?
    ");
    $del->bind_param('i', $almId);
    $del->execute();
    $del->close();

    // 5) Calcular cuántas unidades quedan y la próxima fecha mínima
    $res2 = $mysqli->query("
        SELECT
          COUNT(*) as cnt,
          DATE_FORMAT(MIN(FechaCaducidad), '%d/%m/%Y') AS nextDate
        FROM almacen
        WHERE producto_id = $id
    ");
    $info      = $res2->fetch_assoc();
    $newCount  = intval($info['cnt']);
    $nextDate  = $info['nextDate'] !== null ? $info['nextDate'] : null;

    // Confirmar transacción y devolver resultado
    $mysqli->commit();
    echo json_encode([
        'status'    => 'ok',
        'newCount'  => $newCount,
        'nextDate'  => $nextDate
    ]);

} catch (Exception $e) {
    // En caso de error, deshacer cambios
    $mysqli->rollback();
    http_response_code(500);
    echo json_encode([
        'status'  => 'error',
        'message' => $e->getMessage()
    ]);
}

$mysqli->close();