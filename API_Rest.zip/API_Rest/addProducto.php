<?php
// addProducto.php

/**
 * Lee un JSON con los datos de un nuevo producto, lo inserta en la tabla `productos`
 * y, si corresponde, añade entradas en `almacen` por cada fecha de caducidad.
 */

error_reporting(E_ALL & ~E_NOTICE & ~E_WARNING);
ini_set('display_errors', '0');

header('Content-Type: application/json');
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: POST");
header("Access-Control-Allow-Headers: Content-Type");

// 1) Leer y decodificar el cuerpo JSON
$raw  = file_get_contents('php://input');
$body = json_decode($raw, true);
if (json_last_error() !== JSON_ERROR_NONE) {
    http_response_code(400);
    // JSON mal formado
    echo json_encode(["status" => "error", "message" => "JSON inválido: " . json_last_error_msg()]);
    exit;
}

// 2) Función helper para obtener campos sin importar mayúsculas/minúsculas
function getField(array $body, string $name) {
    if (isset($body[$name])) {
        return $body[$name];
    }
    $uc = ucfirst($name);
    if (isset($body[$uc])) {
        return $body[$uc];
    }
    // Campo no encontrado
    return null;
}

// 3) Validar campos obligatorios (producto, tamano, precio, marca, disponibles, almacen)
$required = ['producto', 'tamano', 'precio', 'marca', 'disponibles', 'almacen'];
$vals = [];
foreach ($required as $f) {
    $v = getField($body, $f);
    if ($v === null) {
        http_response_code(400);
        echo json_encode(["status" => "error", "message" => "Falta el campo \"$f\""]);
        exit;
    }
    $vals[$f] = $v;
}

// 4) Si almacen=1, validar también cantidad y fechas
$fechas = [];
if (intval($vals['almacen']) === 1) {
    $cant  = getField($body, 'cantidad');
    $fecha = getField($body, 'fechaCaducidad');
    if ($cant === null || $fecha === null) {
        http_response_code(400);
        echo json_encode(["status" => "error", "message" => "Falta cantidad o fechaCaducidad para almacen"]);
        exit;
    }
    $vals['cantidad'] = intval($cant);
    // Convertir CSV de cadenas a array de fechas
    $fechas = array_filter(array_map('trim', explode(',', $fecha)));
    if (count($fechas) !== $vals['cantidad']) {
        http_response_code(400);
        echo json_encode([
            "status" => "error",
            "message" => "El número de fechas no coincide con la cantidad"
        ]);
        exit;
    }
}

// 5) Conexión a la BD
$mysqli = new mysqli("localhost", "root", "", "tienda");
if ($mysqli->connect_error) {
    http_response_code(500);
    echo json_encode(["status" => "error", "message" => "Error de conexión: " . $mysqli->connect_error]);
    exit;
}

// 6) Comprobar si el producto ya existe (misma combinación)
$checkStmt = $mysqli->prepare("
    SELECT id 
      FROM productos 
     WHERE Producto = ? 
       AND Tamano   = ? 
       AND Marca    = ?
     LIMIT 1
");
$checkStmt->bind_param("sss", $vals['producto'], $vals['tamano'], $vals['marca']);
$checkStmt->execute();
$checkStmt->store_result();
if ($checkStmt->num_rows > 0) {
    // Producto repetido: devolver código 'exists' y el ID existente
    $checkStmt->bind_result($existingId);
    $checkStmt->fetch();
    $checkStmt->close();
    echo json_encode([
        "status"     => "exists",
        "existingId" => $existingId
    ]);
    $mysqli->close();
    exit;
}
$checkStmt->close();

// 7) Insertar el nuevo producto en `productos`
$stmt = $mysqli->prepare("
    INSERT INTO productos
      (Producto, Tamano, Precio, Marca, Disponibles, Almacen)
    VALUES (?, ?, ?, ?, ?, ?)
");
$stmt->bind_param(
    "ssdsii",
    $vals['producto'],    // nombre
    $vals['tamano'],      // tamaño
    $vals['precio'],      // precio (double)
    $vals['marca'],       // marca
    $vals['disponibles'], // disponibles (0/1)
    $vals['almacen']      // almacen (0/1)
);
if (!$stmt->execute()) {
    http_response_code(500);
    echo json_encode(["status" => "error", "message" => "Error en INSERT productos: " . $stmt->error]);
    exit;
}
$newId = $stmt->insert_id;
$stmt->close();

// 8) Insertar en `almacen` para cada fecha (si corresponde)
if (intval($vals['almacen']) === 1) {
    $stmt2 = $mysqli->prepare("
        INSERT INTO almacen
          (producto_id, Cantidad, FechaCaducidad)
        VALUES (?, ?, STR_TO_DATE(?, '%d/%m/%Y'))
    ");
    foreach ($fechas as $f) {
        // Cada fecha genera una entrada con cantidad 1
        $cantidadPorFecha = 1;
        $stmt2->bind_param("iis", $newId, $cantidadPorFecha, $f);
        if (!$stmt2->execute()) {
            http_response_code(500);
            echo json_encode(["status" => "error", "message" => "Error en INSERT almacen: " . $stmt2->error]);
            exit;
        }
    }
    $stmt2->close();
}

// 9) Respuesta final de éxito
echo json_encode(["status" => "ok", "newId" => $newId]);
$mysqli->close();