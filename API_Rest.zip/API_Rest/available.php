<?php
// available.php
// Endpoint para marcar un producto como disponible o no disponible (0/1)

header('Content-Type: application/json; charset=utf-8');

// 1) Lectura y validación de parámetros POST
$id          = intval($_POST['id']          ?? 0);
$disponibles = intval($_POST['disponibles'] ?? -1);

// Validar que el ID sea positivo y que 'disponibles' sea 0 o 1
if ($id <= 0 || !in_array($disponibles, [0, 1], true)) {
    http_response_code(400);
    echo json_encode([
        'status'  => 'error',
        'message' => 'Parámetros inválidos'
    ]);
    exit;
}

// 2) Conexión a la base de datos
$mysqli = new mysqli('localhost', 'root', '', 'tienda');
if ($mysqli->connect_error) {
    // Error de conexión → devolver 500
    http_response_code(500);
    echo json_encode([
        'status'  => 'error',
        'message' => 'Error conexión: ' . $mysqli->connect_error
    ]);
    exit;
}

// 3) Preparar y ejecutar la actualización
// Usamos consulta preparada para evitar inyección SQL
$stmt = $mysqli->prepare("
    UPDATE productos
       SET Disponibles = ?
     WHERE ID = ?
");
$stmt->bind_param('ii', $disponibles, $id);

// Ejecutar y responder según resultado
if ($stmt->execute()) {
    // Éxito: status ok
    echo json_encode([
        'status'  => 'ok',
        'message' => null
    ]);
} else {
    // Fallo en la ejecución → devolver 500 con mensaje de error
    http_response_code(500);
    echo json_encode([
        'status'  => 'error',
        'message' => $stmt->error
    ]);
}

// 4) Liberar recursos
$stmt->close();
$mysqli->close();