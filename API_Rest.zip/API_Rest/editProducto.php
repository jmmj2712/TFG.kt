<?php
// editProducto.php

/**
 * Actualiza los datos de un producto y su registro en almacén según los parámetros recibidos.
 * - Valida campos de entrada (ID, nombre, tamaño, precio, marca, disponibilidad, almacén).
 * - Si almacén=1, actualiza o inserta la fila correspondiente en `almacen`; si almacén=0, elimina el stock.
 * - Usa transacción para asegurar coherencia entre tablas `productos` y `almacen`.
 */

if (ob_get_level()) ob_end_clean();
header('Content-Type: application/json; charset=utf-8');

// Mostrar todos los errores en desarrollo
error_reporting(E_ALL);
ini_set('display_errors', 1);

// --- Lectura y saneamiento de parámetros POST ---
$id             = intval($_POST['id']             ?? 0);
$producto       = trim($_POST['producto']        ?? '');
$tamano         = trim($_POST['tamano']          ?? '');
$precio         = floatval($_POST['precio']      ?? -1);
$marca          = trim($_POST['marca']           ?? '');
$disponibles    = intval($_POST['disponibles']   ?? -1);
$almacen        = intval($_POST['almacen']       ?? -1);
$cantidad       = isset($_POST['cantidad'])      ? intval($_POST['cantidad']) : null;
$fechaCaducidad = trim($_POST['fechaCaducidad']  ?? '');

$errores = [];
// Validaciones básicas
if ($id <= 0)                         $errores[] = 'ID inválido';
if ($producto === '')                 $errores[] = 'Producto vacío';
if ($tamano === '')                   $errores[] = 'Tamaño vacío';
if ($precio < 0)                      $errores[] = 'Precio inválido';
if ($marca === '')                    $errores[] = 'Marca vacía';
if (!in_array($disponibles, [0,1], true)) $errores[] = 'Disponibles inválido';
if (!in_array($almacen,     [0,1], true)) $errores[] = 'Almacén inválido';
// Si vamos a almacenar, cantidad y fecha no pueden faltar
if ($almacen === 1) {
    if ($cantidad === null || $cantidad < 0)   $errores[] = 'Cantidad inválida';
    if ($fechaCaducidad === '')               $errores[] = 'Fecha caducidad vacía';
}
if (count($errores) > 0) {
    // Responder con error 400 si hay validaciones fallidas
    http_response_code(400);
    echo json_encode([
      'status' => 'error',
      'message'=> implode('; ', $errores),
      'newId'  => null
    ]);
    exit;
}

// Conectar a la base de datos
$mysqli = new mysqli('localhost','root','','tienda');
if ($mysqli->connect_error) {
    http_response_code(500);
    echo json_encode([
      'status' => 'error',
      'message'=> 'Error de conexión: '.$mysqli->connect_error,
      'newId'  => null
    ]);
    exit;
}
$mysqli->begin_transaction();

try {
    // --- 1) Actualizar tabla `productos` ---
    $updProd = $mysqli->prepare("
        UPDATE productos
           SET Producto    = ?,
               Tamano      = ?,
               Precio      = ?,
               Marca       = ?,
               Disponibles = ?,
               Almacen     = ?
         WHERE ID = ?
    ");
    $updProd->bind_param(
        'ssdsiii',
        $producto,    // nombre
        $tamano,      // tamaño
        $precio,      // precio (double)
        $marca,       // marca
        $disponibles, // disponibles (0/1)
        $almacen,     // almacén (0/1)
        $id           // ID del producto
    );
    if (!$updProd->execute()) {
        throw new Exception('Error productos: '.$updProd->error);
    }
    $updProd->close();

    // --- 2) Gestionar tabla `almacen` según flag $almacen ---
    if ($almacen === 1) {
        // Intentar actualizar fila existente de stock
        $updAlm = $mysqli->prepare("
            UPDATE almacen
               SET Cantidad       = ?,
                   FechaCaducidad = STR_TO_DATE(?, '%d/%m/%Y')
             WHERE producto_id = ?
        ");
        $updAlm->bind_param('isi', $cantidad, $fechaCaducidad, $id);
        $updAlm->execute();

        if ($updAlm->affected_rows === 0) {
            // Si no existía, insertar nueva entrada de stock
            $updAlm->close();
            $insAlm = $mysqli->prepare("
                INSERT INTO almacen (producto_id, Cantidad, FechaCaducidad)
                VALUES (?, ?, STR_TO_DATE(?, '%d/%m/%Y'))
            ");
            $insAlm->bind_param('iis', $id, $cantidad, $fechaCaducidad);
            if (!$insAlm->execute()) {
                throw new Exception('Error insert almacen: '.$insAlm->error);
            }
            $insAlm->close();
        } else {
            $updAlm->close();
        }

    } else {
        // Si ya no va en almacén, borrar cualquier registro previo
        $delAlm = $mysqli->prepare("DELETE FROM almacen WHERE producto_id = ?");
        $delAlm->bind_param('i', $id);
        $delAlm->execute();
        $delAlm->close();
    }

    // --- 3) Commit y respuesta de éxito ---
    $mysqli->commit();
    echo json_encode([
      'status' => 'ok',
      'message'=> null,
      'newId'  => null
    ]);
    exit;

} catch (Exception $e) {
    // En caso de error, deshacer cambios y responder con estado 500
    $mysqli->rollback();
    http_response_code(500);
    echo json_encode([
      'status' => 'error',
      'message'=> $e->getMessage(),
      'newId'  => null
    ]);
    exit;
}